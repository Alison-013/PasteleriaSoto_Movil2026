import 'dart:async';
import 'dart:convert';
import 'package:flutter_pasteleria_26/core/constants/api_constants.dart';
import 'package:flutter_pasteleria_26/core/errors/app_exception.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_pasteleria_26/data/models/token_model.dart';


typedef AuthTokenProvider = Future<TokenModal?> Function();


class ApiClient{
   final AuthTokenProvider? _authTokenProvider;
  ApiClient({this._authTokenProvider});

  final http.Client _client = http.Client();

 Future<dynamic> get(String path, { Map<String, String>? query }) async => _send('GET', path, query, null);
 Future<dynamic> post(String path, { Object? body }) async => _send('POST', path, null, body);
 Future<dynamic> put(String path, { Object? body }) async => _send('PUT', path, null, body);
 Future<dynamic> delete(String path) async => _send('DELETE', path, null, null);

  Future<dynamic> _send(String method, String path, Map<String, String>? query, Object? body) async
  {
    final baseUrl = ApiConstants.instance.baseUrl;
    //base URL: http://localhost:5251/api/
    // path : /users
    final uri = Uri.parse('$baseUrl$path').replace(queryParameters: query);

    final Map<String, String> headers = {};
    if (body != null) {
      headers['Content-Type'] = 'application/json';
    }
    
     TokenModal? token = await _authTokenProvider?.call();
    if (token != null && !token.isTokenExpired) {
      headers['Authorization'] = 'Bearer ${token.token}';
    }

    final request = http.Request(method, uri)..headers.addAll(headers);
    if (body !=null){
      request.body = jsonEncode(body);
    }

    final http.Response response;
    try {
      response = await _client.send(request)
      .timeout(ApiConstants.timeoutDuration)
      .then(http.Response.fromStream);
    } on TimeoutException {
      throw const NetworkException('El tiempo de la solicitud ha expirado, intente nuevamente');
    } on http.ClientException {
      throw const NetworkException();
    }on Exception catch (e) {
      throw NetworkException(e.toString());
    }

    if (response.statusCode == 401){
      throw const UnauthorizedExsception();
    }

    return _decode(response);
  }
  
    dynamic _decode(http.Response response){
      if (response.statusCode > 200 || response.statusCode >= 300) {
        throw ServerException('Solicitud fallida', statusCode: response.statusCode);
      }

      if (response.body.isEmpty) return null;

      try {
        return jsonDecode (response.body);
      } on FormatException {
        throw const ParsingException();
      }
     
    }
     
    void dispose() => _client.close();
}